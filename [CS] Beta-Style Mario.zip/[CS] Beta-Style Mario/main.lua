-- name: [CS] Beta-Style Mario
-- description: A remake of the Beta Mario model, as a playable character.\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation

    Use this if you're curious on how anything here works >v<
	(This is an edited version of the Template File by Squishy)
]]

local TEXT_MOD_NAME = "Beta-Style Mario"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_CUSTOM_MODEL = smlua_model_util_get_id("betamario_geo") -- Located in "actors"

local TEX_CUSTOM_LIFE_ICON = get_texture_info("betamario_icon") -- Located in "textures"

-- All Located in "sound" Name them whatever you want. Remember to include the .ogg extension
local VOICETABLE_BETAMARIO = {
    --[CHAR_SOUND_OKEY_DOKEY] = 'StartLevel.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'Silent.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'BetaMarioJump2.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'BetaMarioJump3.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'BetaMarioJump1.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'BetaMarioJump1.ogg', 'BetaMarioJump2.ogg', 'BetaMarioJump3.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'BetaMarioDoubleJump.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'BetaMarioTripleJump.ogg', 'BetaMarioTripleJump.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'BetaMarioDamage.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'Silent.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'Silent.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'Silent.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'BetaMarioTripleJump.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'BetaMarioDamage.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'BetaMarioGrabLedge.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'BetaMarioClimbLedge.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'BetaMarioBurned.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'BetaMarioTripleJump.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'BetaMarioDoubleJump.ogg', 
	[CHAR_SOUND_HRMM] = 'BetaMarioPickUpObject.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'BetaMarioStarGet.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'BetaMarioTripleJump.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'BetaMarioDamage.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'Silent.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'BetaMarioBurned.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'Silent.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'Silent.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'Silent.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'Silent.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'Silent.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'Silent.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'Silent.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'Silent.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'BetaMarioDamage.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'Silent.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'BetaMarioDamage.ogg' -- Booted out of level
}

-- All Located in "actors"
local CAPTABLE_CHAR = {
    normal = smlua_model_util_get_id("betamariocap_geo"),
    wing = smlua_model_util_get_id("betamariowing_geo"),
    metal = smlua_model_util_get_id("betamariometal_geo"),
}

local PALETTE_CHAR = {
    [PANTS]  = "ffffff",
    [SHIRT]  = "ffffff",
    [GLOVES] = "ffffff",
    [SHOES]  = "ffffff",
    [HAIR]   = "ffffff",
    [SKIN]   = "ffffff",
    [CAP]    = "ffffff",
	[EMBLEM] = "ffffff"
}

local HM_CHARNAME2= {
    label = {
        left = get_texture_info("BetaM-LeftHealth"),
        right = get_texture_info("BetaM-RightHealth"),
    },
    pie = {
        [1] = get_texture_info("Pie1"),
        [2] = get_texture_info("Pie2"),
        [3] = get_texture_info("Pie3"),
        [4] = get_texture_info("Pie4"),
        [5] = get_texture_info("Pie5"),
        [6] = get_texture_info("Pie6"),
        [7] = get_texture_info("Pie7"),
        [8] = get_texture_info("Pie8"),
    }
}

local CSloaded = false
local function on_character_select_load()
    CT_CHARNAME2 = _G.charSelect.character_add("Beta-Style Mario", {"A remake of Mario from the SM64 Beta!", "No description added."}, "supr", {r = 255, g = 200, b = 200}, E_MODEL_CUSTOM_MODEL, CT_CHARNAME2, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_CUSTOM_MODEL, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_CUSTOM_MODEL, VOICETABLE_BETAMARIO)
    _G.charSelect.character_add_celebration_star(E_MODEL_CUSTOM_MODEL, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_CUSTOM_MODEL, PALETTE_CHAR)
    _G.charSelect.character_add_health_meter(CT_CHARNAME2, HM_CHARNAME2)
	if _G.customMovesExists then
		_G.customMoves.character_add({name="Beta-Style Mario",triple_jump_twirling_on=true})
	end

    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BETAMARIO then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BETAMARIO then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)